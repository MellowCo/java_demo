package com.li.service;

import com.li.entity.User;

import java.util.List;

public interface IUserService {
    /**
     *功能描述 查询所有用户
     * @author li
     * @date 2019/7/17
     * @param
     * @return List<User>
     */
    List<User> queryAllUser();

    /**
     *功能描述 根据学号查询学生
     * @author li
     * @date 2019/7/17
     * @param id
     * @return com.li.entity.User
     */
    User queryUserById(int id);

    /**
     *功能描述 实现注册
     * @author li
     * @date 2019/7/16
     * @param User
     * @return void
     */
    void register(User user);

    /**
     *功能描述 更改用户信息
     * @author li
     * @date 2019/7/17
     * @param user
     * @return void
     */
    void update(User user);

    /**
     *功能描述 根据id 删除用户
     * @author li
     * @date 2019/7/17
     * @param id
     * @return void
     */
    void delUserById(int id);

    /**
     *功能描述 实现登陆
     * @author li
     * @date 2019/7/16
     * @param userName  用户名
     * @param pwd  密码
     * @return int
     */
    int login(String userName,String pwd);
}
