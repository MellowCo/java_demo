package com.li.entity;

/**
 * @author li
 * @version 1.0
 * @ClassName Person
 * @date 2019/7/16 14:08
 */

public class Person {
    private String username;
    private String password;
    private String email;
    private String name;
    private String tel;
    private String sex;
    private String birthday;

    public Person(String username, String password, String email, String name, String tel, String sex, String birthday) {
        this.username = username;
        this.password = password;
        this.email = email;
        this.name = name;
        this.tel = tel;
        this.sex = sex;
        this.birthday = birthday;
    }

    public Person() {
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getTel() {
        return tel;
    }

    public void setTel(String tel) {
        this.tel = tel;
    }

    public String getSex() {
        return sex;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }

    public String getBirthday() {
        return birthday;
    }

    public void setBirthday(String birthday) {
        this.birthday = birthday;
    }

    @Override
    public String toString() {
        return "Person{" +
                "username='" + username + '\'' +
                ", password='" + password + '\'' +
                ", email='" + email + '\'' +
                ", name='" + name + '\'' +
                ", tel='" + tel + '\'' +
                ", sex='" + sex + '\'' +
                ", birthday=" + birthday +
                '}';
    }
}
