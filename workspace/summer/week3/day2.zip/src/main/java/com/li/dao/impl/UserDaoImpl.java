package com.li.dao.impl;

import com.li.dao.IUserDao;
import com.li.entity.Person;
import com.li.entity.User;
import com.li.utils.JdbcUtils;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;

import java.util.List;

/**
 * @author li
 * @version 1.0
 * @ClassName UserDaoImpl
 * @date 2019/7/16 14:13
 */

public class UserDaoImpl implements IUserDao {
    private JdbcTemplate jt = new JdbcTemplate(JdbcUtils.getDs());

    @Override
    public void addUser(User user) {
        String sql = "insert into user values(null,?,?,?,?,?,?)";
        jt.update(sql, user.getName(), user.getgender(), user.getAge(), user.getaddress(), user.getQq(), user.getEmail());
    }

    @Override
    public List<User> queryAllUser() {
        String sql = "select * from user";
        return jt.query(sql, new BeanPropertyRowMapper<User>(User.class));
    }

    @Override
    public User queryUserById(int id) {
        String sql = "select * from user where id = ?";
        return jt.query(sql, new BeanPropertyRowMapper<User>(User.class), id).get(0);
    }

    @Override
    public void updateUser(User user) {
        String sql = "update user set name = ? ,gender = ? ,age = ? ,address = ? ,qq = ?,email = ? where id = ?";
        jt.update(sql, user.getName(), user.getgender(), user.getAge(), user.getaddress(), user.getQq(), user.getEmail(), user.getId());
    }

    @Override
    public void delUserById(int id) {
        String sql = "delete from user where id = ?";
        jt.update(sql,id);
    }


    @Override
    public Person queryPersonByUserName(String userName) {
        String sql = "select * from person where username = ?";
        List<Person> person = jt.query(sql, new BeanPropertyRowMapper<Person>(Person.class), userName);

        if (person.isEmpty()) {
            return null;
        } else {
            return person.get(0);
        }
    }


    @Override
    public Boolean checkPwd(String userName, String pwd) {
        String sql = "select * from person where username = ? and password =?";
        List<Person> person = jt.query(sql, new BeanPropertyRowMapper<Person>(Person.class), userName, pwd);

        if (person.isEmpty()) {
            return false;
        } else {
            return true;
        }
    }

}
