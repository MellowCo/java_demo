package com.li.servlet;

import com.li.entity.User;
import com.li.service.IUserService;
import com.li.service.impl.UserServiceImpl;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

/**
 * @author li
 * @version 1.0
 * @ClassName FindUserByPageServlet
 * @date 2019/7/17 13:49
 */
@WebServlet("/findUserByPageServlet")
public class FindUserByPageServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        IUserService is = new UserServiceImpl();
        List<User> users = is.queryAllUser();

        request.setAttribute("list",users);
        request.getRequestDispatcher("list.jsp").forward(request, response);
    }
}
