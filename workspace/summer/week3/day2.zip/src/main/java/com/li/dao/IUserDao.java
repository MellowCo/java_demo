package com.li.dao;

import com.li.entity.Person;
import com.li.entity.User;

import java.util.List;

public interface IUserDao {
   /**
    *功能描述 查询所有学生
    * @author li
    * @date 2019/7/17
    * @param
    * @return java.util.List<com.li.entity.User>
    */
   List<User> queryAllUser();

   /**
    *功能描述 添加用户
    * @author li
    * @date 2019/7/16
    * @param User
    * @return void
    */
    void addUser(User user);

    /**
     *功能描述 根据用户名查找用户
     * @author li
     * @date 2019/7/16
     * @param userName
     * @return Person
     */
    Person queryPersonByUserName(String userName);

    /**
     *功能描述 根据学号查询学生
     * @author li
     * @date 2019/7/17
     * @param id
     * @return com.li.entity.User
     */
    User queryUserById(int id);

    /**
     *功能描述 更改用户信息
     * @author li
     * @date 2019/7/17
     * @param user
     * @return void
     */
    void updateUser(User user);

    /**
     *功能描述 根据id 删除用户
     * @author li
     * @date 2019/7/17
     * @param id
     * @return void
     */
    void delUserById(int id);

    /**
     *功能描述 验证用户名和密码
     * @author li
     * @date 2019/7/16
     * @param userName 用户名
     * @param pwd 密码
     * @return java.lang.Boolean
     */
    Boolean checkPwd(String userName,String pwd);

}
